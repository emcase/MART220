var mainColor =  180;


function setup() {
    createCanvas(640, 480);
    background(0,255,255);
    frameRate(25);
    rectMode(CENTER);
}
    
function draw() {
    fill(random(255),random(102),random(204), random(255));
  
    // circles
    var size= 50;
    var size2= 100;
    ellipse(random(width), random(height), size, size2);
    
    // rotating triangles
    
    triangle(200,300,random(250),random(25),random(300),random(150));
    rotate(PI/4);

    //Name in Block Style
    textFont('Block');
    textSize(24);
    stroke(20);
    fill(255);
    text('by Michelle Casey',250,100);

    if (frameCount % 2 == 0) {
        
      mainColor = 255 - mainColor; // 255 0 255 0 255 0 ..
     
    }
    
    saveFrames("myMovie",".png",1,25);
    

    if (frameCount > 100) { //2 second * 25 fps = 25
        noLoop();
    }
}