class imageclass{

    constructor(moviepath, x, y)
    {
        this.moviepath = moviepath;
        this.x = x;
        this.y = y;
       
    }
 

    
    getImage()
    {
        var myImage = loadImage(this.moviepath);
        return myImage;
    }
    getX()
    {
        return this.x;
    }
    getY()
    {
        return this.y;
    }
    setX(x)
    {
        this.x = x;
    }
    setY(y)
    {
        this.y = y;
    }
    }