
function setup() {
  createCanvas(800, 600);
  background(0);
  
}

function draw() {
 
  img = createImage(20, 20);
  img.loadPixels();

//create image 2
  img2 = createImage(800, 600);
  img2.loadPixels();
  for (let i = 0; i < img2.width; i++) {
    for (let j = 0; j < img2.height; j++) {
      var c = color(204, 204, 255);
      img2.set(i, j,c)
  }
}
//draw letter M

  img2.set( 720, 575, color(0,0,0));
  img2.set( 720, 576, color(0,0,0));
  img2.set( 720, 577, color(0,0,0));
  img2.set( 720, 578, color(0,0,0));
  img2.set( 720, 579, color(0,0,0));
  img2.set( 720, 580, color(0,0,0));
  img2.set( 720, 581, color(0,0,0));
  img2.set( 720, 582, color(0,0,0));
  img2.set( 720, 583, color(0,0,0));
  img2.set( 720, 584, color(0,0,0));
  img2.set( 721, 575, color(0,0,0));
  img2.set( 722, 575, color(0,0,0));
  img2.set( 723, 575, color(0,0,0));
  img2.set( 723, 576, color(0,0,0));
  img2.set( 723, 577, color(0,0,0));
  img2.set( 723, 578, color(0,0,0));
  img2.set( 723, 579, color(0,0,0));
  img2.set( 723, 580, color(0,0,0));
  img2.set( 723, 581, color(0,0,0));
  img2.set( 723, 582, color(0,0,0));
  img2.set( 724, 575, color(0,0,0));
  img2.set( 725, 575, color(0,0,0));
  img2.set( 726, 575, color(0,0,0));
  img2.set( 726, 576, color(0,0,0));
  img2.set( 726, 577, color(0,0,0));
  img2.set( 726, 578, color(0,0,0));
  img2.set( 726, 579, color(0,0,0));
  img2.set( 726, 580, color(0,0,0));
  img2.set( 726, 581, color(0,0,0));
  img2.set( 726, 582, color(0,0,0));
  img2.set( 726, 583, color(0,0,0));
  img2.set( 726, 584, color(0,0,0));
  

//draw letter C

  img2.set( 735, 575, color(0,0,0));
  img2.set( 735, 576, color(0,0,0));
  img2.set( 735, 577, color(0,0,0));
  img2.set( 735, 578, color(0,0,0));
  img2.set( 735, 579, color(0,0,0));
  img2.set( 735, 580, color(0,0,0));
  img2.set( 735, 581, color(0,0,0));
  img2.set( 735, 582, color(0,0,0));
  img2.set( 735, 583, color(0,0,0));
  img2.set( 735, 584, color(0,0,0));
  img2.set( 736, 584, color(0,0,0));
  img2.set( 737, 584, color(0,0,0));
  img2.set( 738, 584, color(0,0,0));
  img2.set( 739, 584, color(0,0,0));
  img2.set( 740, 584, color(0,0,0));
  img2.set( 736, 575, color(0,0,0));
  img2.set( 737, 575, color(0,0,0));
  img2.set( 738, 575, color(0,0,0));
  img2.set( 739, 575, color(0,0,0));
  img2.set( 740, 575, color(0,0,0));

  img2.updatePixels();

  // Draw squares in ombre effect
  for (var y = 0; y < img.height-2; y++) {
      for (var x = 0; x < img.width-1; x++) {
          var c = color(y * 15, x * 1, 100);
          img.set(x , y, c);
          
      }
  }

  // draw random squares (50)
  for (var i = 0; i < 50; i++) {
    var c = color(204,204,255);
    img.set(random(25), random(25), c);
  }
  
  img.updatePixels();
  noSmooth();

  image(img2, 0, 0,width,height);
  image(img, 20, 30, width, height);

  noLoop();

}

