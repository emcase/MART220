//This is the sketch.jspage

var movie;
var movies = [];
var animation = [];
var movieObjects = [];
var i = 0;
var x = 0;
var counter = 0;
var edge = false;

// Define the interval variable 
var myInterval;

function preload() {


// Bring in the movie assets
// and create all our objects
    
    movie = new imageclass('assets/Movie1.png', 0, 0);
    movieObjects[0] = movie;
    movie = new imageclass('assets/Movie2.png', 0, 0);
    movieObjects[1] = movie;
    movie = new imageclass('assets/Movie3.png', 0, 0);
    movieObjects[2] = movie;
    movie = new imageclass('assets/Movie4.png', 0, 0);
    movieObjects[3] = movie;
    movie = new imageclass('assets/Movie5.png', 0, 0);
    movieObjects[4] = movie;
    movie = new imageclass('assets/Movie6.png', 0, 0);
    movieObjects[5] = movie;
    movie = new imageclass('assets/Movie7.png', 0, 0);
    movieObjects[6] = movie;
    movie = new imageclass('assets/Movie8.png', 0, 0);
    movieObjects[7] = movie;
    movie = new imageclass('assets/Movie9.png', 0, 0);
    movieObjects[8] = movie;
    movie = new imageclass('assets/Movie10.png', 0, 0);
    movieObjects[9] = movie;

    
    for (var i = 0; i < movieObjects.length; i++) 
    {
        animation[i] = movieObjects[i].getImage(); 
    }
}

// create the canvas
function setup() {

    createCanvas(900, 900);
 //setInterval(incrementIndex, 100);
    myInterval = setInterval(incrementIndex, 100);
}

// display all the frames using the draw function as a loop
function draw() {

    background(0,0,255);
    // upper border
    noStroke();
    fill(215,189,226);
     rect(0,0,700,25);
    // left border
    rect(0,25,25,500);
    // bottom border
    rect(25,475,700,25);
    // right border
    rect(675,25,25,500);

    // draw each frame based on the index in the array
    if(keyIsPressed){
    
        // display the image

        image(animation[1], movieObjects[1].getX(), movieObjects[1].getY());

        // stop the idle interval
        clearInterval(myInterval);

        // set the variable to null
        myInterval = null;
    }     
        
    else
    {
        image(animation[i], movieObjects[i].getX(), movieObjects[i].getY());

    } 
    }    
function incrementIndex()
{
     // increment the index
     i += 1;
    
     // if we reach the end of the array, start over
     if (i >= animation.length) {
         i = 0;
     }
}




