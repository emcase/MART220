class Particle {

    constructor(x,y) {
      this.x = x;
      this.y = y;
      this.vx = random(-1, 1);
      this.vy = random(-8, -1);
      this.life = 255;

      // pick a random color
      this.color = color(255);
      let r = random(3);
      if(r < 1){
        this.color = color(255,100,20,50); // orange
      } else if(r >= 1 && r < 2 ){
        this.color = color(255, 200, 10, 50); // yellow
      } else if(r >= 2 ){
        this.color = color(255, 80, 5, 50); // reddish
    }
    
    }
  
    finished() {
      return this.life < 0;
      /*
      background(0,0,255);
      noStroke();
      fill(215,189,226);
      border();
      */
      
    }
  
    update() {
      this.x += this.vx;
      this.y += this.vy;
      this.life -= 5;
    }
  
    display() {
      noStroke();
      //stroke(255);
      fill(this.color, this.life);
      ellipse(this.x, this.y, 15);
    }
  
  }
