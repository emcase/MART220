//This is the sketch.jspage

var dogObjects;
var catObjects;
var result, runresult, leftrunresult, catresult,attackresult;
var sun;
var hydrant;
var flower;
var butterfly;
var health = 200;
const particles = [];

// define the key codes for each letter
var w = 87;
var s = 83;
var a = 65;
var d = 68;
var x = 88;
var q = 81;



function preload() {
  result = loadStrings('assets/characteridle.txt');
  runresult = loadStrings('assets/characterrun.txt');
  leftrunresult = loadStrings('assets/characterrunleft.txt');
  catresult = loadStrings('assets/charactercat.txt');
  attackresult = loadStrings('assets/characterattack.txt');
  
}

function setup() {
    createCanvas(700,500);  
    dogObjects = createSprite(300, 250);
    dogObjects.setCollider('rectangle',0,0,150,200,0);
    catObjects = createSprite(500, 250);
    catObjects.setCollider('rectangle',0,0,150,200,0);
    dogObjects.addAnimation('idle', result[0], result[result.length-1]);
    dogObjects.addAnimation('run', runresult[0], runresult[runresult.length-1]);
    dogObjects.addAnimation('runL', leftrunresult[0], leftrunresult[leftrunresult.length-1]);
    dogObjects.addAnimation('attack', attackresult[0], attackresult[attackresult.length-1]);
    catObjects.addAnimation('catIdle', catresult[0], catresult[catresult.length-1]);

    sun = createSprite(500,100);
    sun.setCollider('circle',0,0,35,35,0);
    hydrant = createSprite(300,200);
    hydrant.setCollider('rectangle',0,0,50,110,0);
    flower = createSprite(400, 100);
    flower.setCollider('circle',0,0,35,35,0);
    butterfly = createSprite(450, 250);
    butterfly.setCollider('circle',0,0,40,40,0);
   

    //add imageGroup
    
    sun.addImage (loadImage('assets/sun.png'));
    hydrant.addImage(loadImage('assets/hydrant.png'));
    flower.addImage(loadImage('assets/flower.png'));
    butterfly.addImage(loadImage('assets/butterfly.png'));

    //add imageGroup to Sprite Group
    imageGroup = new Group();
    imageGroup.add(sun);
    imageGroup.add(hydrant);
    imageGroup.add(flower);
    imageGroup.add(butterfly);

   
    

    //  generate random positions for imageGroup
    sun.position.x = random(100,600);
    sun.position.y = random(100,400);
    hydrant.position.x = random(100,600);
    hydrant.position.y = random(100,400);
    flower.position.x = random(100,600);
    flower.position.y = random(100,400);
    butterfly.position.x = random(100,600);
    butterfly.position.y = random(100,400);
  
}


// display all the frames using the draw function as a loop
function draw() 
{
  background(0,0,255);
  noStroke();
  fill(215,189,226);
  border();

  // constrain x and y for dog to keep within canvas
  dogObjects.position.x = constrain (dogObjects.position.x, 50, 750);
  dogObjects.position.y = constrain (dogObjects.position.y,40,460);
   
    if(keyIsDown(d))
    {
      dogObjects.changeAnimation('run');
      dogObjects.velocity.x += .5;
      if (imageGroup.length >= 0)
      {
        if (dogObjects.collide(imageGroup)) 
        {
          dogObjects.changeAnimation('idle');
        }
      }
      
    }
    else if(keyIsDown(a))
    {
      dogObjects.changeAnimation('runL');
      dogObjects.velocity.x -= .5;
      if (imageGroup.length >= 0)
      {
        if (dogObjects.collide(imageGroup)) 
        {
          dogObjects.changeAnimation('idle');
        }
      }
      
    }
    else if(keyIsDown(w))
    {
      dogObjects.changeAnimation('idle');
      dogObjects.velocity.y -= .5;
      if (imageGroup.length >= 0)
      {
        if (dogObjects.collide(imageGroup)) 
        {
          dogObjects.changeAnimation('idle');
        }
      }
      
    }
    else if(keyIsDown(s))
    {
      dogObjects.changeAnimation('idle');
      dogObjects.velocity.y += .5;
      if (imageGroup.length >= 0)
      {
        if (dogObjects.collide(imageGroup)) 
        {
          dogObjects.changeAnimation('idle');
        }
     }
      
    }
    else if(keyIsDown(x))
    {
      dogObjects.changeAnimation('attack');
      
      if (imageGroup.length >= 0)
      {
      for (let i = imageGroup.length -1; i >= 0; i--)
        {
        if(imageGroup[i].overlap(dogObjects))
        {
          createParticles(imageGroup[i].position.x, imageGroup[i].position.y);
        
          health -= 2;
          if(health <= 0)
          { 
          imageGroup[i].remove();
          }
        }  
       }  
     }  
    }
    
    else
    {
      dogObjects.changeAnimation('idle');
      dogObjects.velocity.x = 0;
      dogObjects.velocity.y = 0;
    }

    // display positon of sprites on screen
    
    dogObjects.debug = mouseIsPressed;
    catObjects.debug = mouseIsPressed;
    sun.debug = mouseIsPressed;
    flower.debug = mouseIsPressed;
    hydrant.debug = mouseIsPressed;
    butterfly.debug = mouseIsPressed;
  
    // when all imageGroup are removed end game
    if (imageGroup.length <= 0)
    { 
    winner();
    }
    escape();
    drawSprites();

 
}
// character makes it to exit
function winner()
    {
            background(204, 255, 102);
            fill(215,189,226);
            border();
            fill(color('black'));
            stroke(8);
            textSize(40);
            textAlign (CENTER);
            text("Game Over",width/2-50, height/2-50);
            removeSprites();
       
    }  

// escape message
function escape()
{
      textSize(10);
      textStyle(BOLD);
      fill(200);
      text("Press 'Q' to Escape Game", width-670,height-40);
      
    if(keyIsDown(q)){
      background(204, 255, 102);
      fill(215,189,226);
      border();
      fill(color('black'));
      stroke(8);
      textSize(40);
      textAlign (CENTER);
      text("Game Over",width/2-50, height/2-50);
      removeSprites();      
      }

}

// create border
function border(){
  // upper border
  noStroke();
  rect(0,0,700,25);
  // left border
  rect(0,25,25,500);
  // bottom border
  rect(25,475,700,25);
  // right border
  rect(675,25,25,525);
}

// create particles
function createParticles(x,y)
{
let len = particles.length;
for (let i = 0; i< 10; i++) {
    let p = new Particle(x,y);
    particles.push(p);
  }
  for (let i = len - 1; i >= 0; i--) {
    particles[i].update();
    particles[i].display();
    if (particles[i].finished()) {
      // remove this particle
      particles.splice(i,1);
    }
  }
}

