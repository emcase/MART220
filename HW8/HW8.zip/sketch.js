
// x and y for my character
var characterX = 240;
var characterY = 0;
var shapeSize = 1;

// define the key codes for each letter
var w = 87;
var s = 83;
var a = 65;
var d = 68;

function setup() {
    createCanvas(900, 500,WEBGL);   
}

function draw() {
    background(153,204,255);
    stroke(0);
    fill(0);

    //draw box
    translate(100, 0, 0);
    fill(255,102,0);
    rotateZ(frameCount * 0.01);
    rotateX(frameCount * 0.01);
    rotateY(frameCount * 0.01);
    box(50);
    
    //draw plane
    translate(-240, -100, 0);
    fill(51,51,255);
    push();
    rotateX(frameCount * 0.05);
    rotateY(frameCount * 0.01);
    plane(70);
    pop();

    // draw cone
    translate(-150, height*-0.25, 100);
    fill(255,0,255);
    push();
    //rotateZ(frameCount * 0.01);
    rotateX(frameCount * 0.01);
    rotateY(frameCount * 0.03);
    cone(50, 70);
    pop();

    // draw sphere
    fill(25);
    stroke(200);
    push();
    translate(100, height*-0.25, 100);
    rotateZ(frameCount * 0.09);
    sphere(100);
    pop();

    //draw torus
    translate(240, 0, 0);
    normalMaterial();
    push();
    rotateZ(frameCount * 0.03);
    //rotateX(frameCount * 0.01);
    //rotateY(frameCount * 0.01);
    torus(70, 20);
    pop();

     //draw cyclinder
     translate(characterX, characterY, 0);
     fill(102,255,102);
     stroke(200);
     scale(shapeSize)
     push();
     rotateZ(frameCount * 0.01);
     rotateX(frameCount * 0.01);
     rotateY(frameCount * 0.01);
     cylinder(40, 50);
     pop();
    
    //  Move cylinder
    cylinderMoves();
    } 

//Move cylinder Function

function cylinderMoves()
{
// handle keys
      if(keyIsDown(w))
      {
          characterY -= 10;
      }
      if(keyIsDown(s))
      {
          characterY += 10;
      }
      if(keyIsDown(a))
      {
          characterX -= 10;
          shapeSize -= 0.1;
      }
      if(keyIsDown(d)) 
      {
          characterX += 10;
          shapeSize += 0.1;
          
          
      }
    }

function keyPressed(){
    if ( keyCode === LEFT_ARROW) {
        characterX -= 10;
        shapeSize -= 0.1;
    }
    else if(keyCode === RIGHT_ARROW) {
        characterX += 10;
        shapeSize += 0.1;
    }
    else if (keyCode === UP_ARROW){
        characterY -= 10;
    }
    else if (keyCode === DOWN_ARROW) {
        characterY += 10;
    }

  }