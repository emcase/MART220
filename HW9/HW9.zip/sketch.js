
// create six variables for textures 
let tiger;
let plant;
let flowers;
let clouds;
let ocean;
let pebbles;

// create a variable for the model
let door;

// set shape array
let shapeArray = [];

// load assets
function preload() {
  tiger = loadImage('assets/tiger.jpg');
  plant = loadImage('assets/plant.jpg');
  flowers = loadImage('assets/flowers.jpg');
  ocean = loadImage('assets/ocean.jpg');
  pebbles = loadImage('assets/pebbles.jpg');
  clouds = loadImage('assets/clouds.jpg');

  newFont = loadFont('Assets/PottaOne-Regular.ttf');

  door = loadModel('assets/door.obj', true);
}

// create the canvas of 800 x 600 
function setup() {
  createCanvas(800, 600, WEBGL);

// add six simple shapes to the simple shape array
  
  shapeArray.push(new shapeclass("box", 100, 100, 100, 100, -100, 0, 0.1, 0, ocean));
  shapeArray.push(new shapeclass("sphere", 30, 30, 30, 200, -200, 0.02, 0.01, 0, flowers));
  shapeArray.push(new shapeclass("cylinder", 50, 100, 0, 200, 20, 0, 0.01, 0, clouds));
  shapeArray.push(new shapeclass("cone", 80, 50, 0, -300, -200, 0, 0.04, 0, flowers));
  shapeArray.push(new shapeclass("torus", 50, 10, 0, 150, -150, 0.02, 0.02, 0, pebbles));
  shapeArray.push(new shapeclass("ellipsoid", 30, 20, 80, -250, 150, 0, 0.0025, 0, plant));

  
}

function draw() {
  //background(clouds);
  background(153, 204, 255);
  normalMaterial();

  // title and name
  textFont(newFont);
  textSize(26);
  fill(0, 0, 255);
  text(' Door to Adventure', -400,-260);
  textSize(18);
  text('     by Michelle Casey', -400,-240);
 
  // custom shape textured
  image(tiger);
  
  // display the simple shapes
  for (var i = 0; i < shapeArray.length; i++) {
    shapeArray[i].draw(frameCount);
  }
  // add a custom shape
  push();
  //rotateX(frameCount * 0.01);
  rotateY(frameCount * 0.01);
  translate(-250, -250);
  texture(tiger);
  beginShape();
  vertex(0, 0, 100, 0, 0);
  vertex(150, 0, 50, 1, 0);
  vertex(150, 150, 100, 1, 1);
  vertex(0, 150, 50, 0, 1);
  endShape(CLOSE);
  pop();

  // add a texture model
  push();
  scale(2);
  //rotateX(frameCount * 0.01);
  rotateY(frameCount * 0.0025);
  texture(clouds);
  model(door);
  pop();
}


  


