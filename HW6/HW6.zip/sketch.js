//This is the sketch.jspage

var dogObjects;
var catObjects;
var result, runresult, leftrunresult, catresult;
var sun;
var hydrant;
var flower;
var butterfly;
// define the key codes for each letter
var w = 87;
var s = 83;
var a = 65;
var d = 68;
var x = 88;

var barkSound;

function preload() {
  result = loadStrings('assets/characteridle.txt');
  runresult = loadStrings('assets/characterrun.txt');
  leftrunresult = loadStrings('assets/characterrunleft.txt');
  catresult = loadStrings('assets/charactercat.txt');
  
  // Load Dog Bark Sound
  soundFormats('mp3');
  barkSound = loadSound('assets/dogBark.mp3');
}

function setup() {
    createCanvas(700,500);  
    dogObjects = createSprite(300, 250);
    dogObjects.setCollider('rectangle',0,0,150,200,0);
    catObjects = createSprite(500, 250);
    catObjects.setCollider('rectangle',0,0,150,200,0);
    dogObjects.addAnimation('idle', result[0], result[result.length-1]);
    dogObjects.addAnimation('run', runresult[0], runresult[runresult.length-1]);
    dogObjects.addAnimation('runL', leftrunresult[0], leftrunresult[leftrunresult.length-1]);
    catObjects.addAnimation('catIdle', catresult[0], catresult[catresult.length-1]);
    

    sun = createSprite(500,100);
    sun.setCollider('circle',0,0,35,35,0);
    hydrant = createSprite(300,200);
    hydrant.setCollider('rectangle',0,0,50,110,0);
    flower = createSprite(400, 100);
    flower.setCollider('circle',0,0,35,35,0);
    butterfly = createSprite(450, 250);
    butterfly.setCollider('circle',0,0,40,40,0);
   

    //add images
    
    sun.addImage(loadImage('assets/sun.png'));
    hydrant.addImage(loadImage('assets/hydrant.png'));
    flower.addImage(loadImage('assets/flower.png'));
    butterfly.addImage(loadImage('assets/butterfly.png'));

    //  generate random positions for images
    sun.position.x = random(100,600);
    sun.position.y = random(100,400);
    hydrant.position.x = random(100,600);
    hydrant.position.y = random(100,400);
    flower.position.x = random(100,600);
    flower.position.y = random(100,400);
    butterfly.position.x = random(100,600);
    butterfly.position.y = random(100,400);
  
  
  //dog barking loop
    barkSound.loop();

  //dog barking stop
    barkSound.stop();
}

// display all the frames using the draw function as a loop
function draw() 
{
  background(0,0,255);
  // upper border
  noStroke();
  fill(215,189,226);
   rect(0,0,700,25);
  // left border
  rect(0,25,25,500);
  // bottom border
  rect(25,475,700,25);
  // right border
  rect(675,25,25,325);


  // constrain x and y for dog to keep within canvas
  dogObjects.position.x = constrain (dogObjects.position.x, 50, 750);
  dogObjects.position.y = constrain (dogObjects.position.y,40,460);

  if(keyIsDown(d))
    {
      dogObjects.changeAnimation('run');
      dogObjects.setSpeed(1.5,0);
     
      
      if(dogObjects.collide(sun) || dogObjects.collide(hydrant) || dogObjects.collide(flower) || dogObjects.collide(butterfly) || dogObjects.collide(catObjects))
      {
        dogObjects.changeAnimation('idle');
      }
    }
    else
    if(keyIsDown(a))
    {
      dogObjects.changeAnimation('runL');
      dogObjects.setSpeed(1.5,180);
     
      
      if(dogObjects.collide(sun) || dogObjects.collide(hydrant) || dogObjects.collide(flower) || dogObjects.collide(butterfly))
      {
        dogObjects.changeAnimation('idle');
      }
    }
    else
    if(keyIsDown(w))
    {
      dogObjects.changeAnimation('idle');
      dogObjects.setSpeed(1.5,270);
     
      
      if(dogObjects.collide(sun) || dogObjects.collide(hydrant) || dogObjects.collide(flower) || dogObjects.collide(butterfly))
      {
        dogObjects.changeAnimation('idle');
      }
    }
    else
    if(keyIsDown(s))
    {
      dogObjects.changeAnimation('idle');
      dogObjects.setSpeed(1.5,90);
     
      
      if (dogObjects.collide(sun) || dogObjects.collide(hydrant) || dogObjects.collide(flower) || dogObjects.collide(butterfly))
      {
        dogObjects.changeAnimation('idle');
      }
    }
    else
  
    {
      dogObjects.changeAnimation('idle');
      dogObjects.velocity.x = 0;
      dogObjects.velocity.y = 0;
  
    }
    
  // show positon of sprites on screen
    dogObjects.debug = mouseIsPressed;
    catObjects.debug = mouseIsPressed;
    sun.debug = mouseIsPressed;
    flower.debug = mouseIsPressed;
    hydrant.debug = mouseIsPressed;
    butterfly.debug = mouseIsPressed;

    escape();
    exit();
    winner();
    drawSprites();
  

}
// character makes it to exit
function winner()
    {
      
      if(dogObjects.position.x > width && dogObjects.position.y > width-300)
        {
            background(204, 255, 102);
            // upper border
            noStroke();
            fill(215,189,226);
            rect(0,0,700,25);
            // left border
            rect(0,25,25,500);
            // bottom border
            rect(25,475,700,25);
            // right border
            rect(675,25,25,525);
            fill(color('black'));
            stroke(8);
            textSize(40);
            textAlign (CENTER);
            text("Game Over",width/2-50, height/2-50);
            barkSound.pause();
            removeSprites();
        }
    }  
// exit message
function exit()
{
      textSize(20);
      textStyle(BOLD);
      fill(200);
      text("EXIT HERE >>>", width-150,height-40);
}
// escape message
function escape()
{
      textSize(10);
      textStyle(BOLD);
      fill(200);
      text("Press 'X' to Escape Game", width-670,height-40);
      
    if(keyIsDown(x)){
      background(204, 255, 102);
  
      // upper border
      noStroke();
      fill(215,189,226);
      rect(0,0,700,25);
      // left border
      rect(0,25,25,500);
      // bottom border
      rect(25,475,700,25);
      // right border
      rect(675,25,25,525);
      fill(color('black'));
      stroke(8);
      textSize(40);
      textAlign (CENTER);
      text("Game Over",width/2-50, height/2-50);
      barkSound.pause();
      removeSprites();      
      }

}
function keyPressed() {
  if (barkSound.isPlaying()) {
    // .isPlaying() returns a boolean
    barkSound.stop();
    return false;
    //background(255, 0, 0);
  } else {
    barkSound.play();
    //background(0, 255, 0);
  }
}
